# Claude Token Optimizer for Plug

A tiny, dependency-free Claude Code plugin + MCP server. It reduces avoidable context overhead without pretending that lossy pruning is safe.

## What it does

- **Headroom-inspired output compression:** deduplicates repeated lines, compacts whitespace, minifies JSON, and ranks old log/context blocks by relevance and recency.
- **LLMLingua-inspired budget targeting:** chooses which complete blocks to retain for a goal. This is a lightweight deterministic heuristic, **not** LLMLingua and does not load a model.
- **Ponytail-inspired coding discipline:** tells Claude to inspect existing code, use built-ins, avoid unnecessary scaffolding and dependencies, and make the smallest correct change.
- **MCP compressor workflow:** exposes compression/recovery tools directly to Claude Code.
- **Reversible recovery:** stores the original locally in SQLite and returns a `vault_id`; `retrieve_original` restores it. `forget_original` deletes it.
- **Claude token counting:** optional call to Anthropic `POST /v1/messages/count_tokens` when `ANTHROPIC_API_KEY` is configured. No content is sent to Anthropic by local compression tools.

## Install in Claude Code

1. Extract this folder somewhere permanent.
2. From the folder that contains it, launch Claude Code with the plugin directory:

   ```bash
   claude --plugin-dir ./claude-token-optimizer
   ```

3. Start a fresh Claude Code session. The plugin's `.mcp.json` registers the local stdio MCP server and the skill is loaded as plugin guidance.

Python 3.10+ is required. No pip packages, model downloads or API key are required for local compression.

To use Anthropic's exact count endpoint, set `ANTHROPIC_API_KEY` in the environment before launching Claude Code. The key is read from the environment and is never written to the vault. Only the explicit `claude_count_tokens` tool sends the supplied messages to Anthropic.

## MCP tools

| Tool | Purpose |
|---|---|
| `compress_text` | Compress text, tool output, logs, Markdown or JSON |
| `compress_messages` | Compress older assistant/tool messages while preserving system/developer/user turns by default |
| `retrieve_original` | Restore the original by `vault_id` |
| `forget_original` | Permanently delete one vault item |
| `claude_count_tokens` | Exact count through Anthropic API (optional) |

Example request to `compress_text`:

```json
{
  "text": "...large tool output...",
  "goal": "Find the cause of the test failure",
  "budget_tokens": 1800,
  "mode": "auto",
  "reversible": true
}
```

## Safety and limitations

- Local compression is deterministic and offline. It is **not semantic understanding** and does not run LLMLingua, a transformer, or another LLM.
- The local token figure is a rough UTF-8 byte heuristic (~3.7 bytes/token), not a Claude tokenizer. Use `claude_count_tokens` for an API count.
- System/developer/user messages, recent turns, directive-like lines, errors, numeric values, links, headings and fenced code are protected. If protected content alone exceeds a budget, the result may exceed it rather than silently deleting it.
- `compress_messages` only prunes older assistant/tool content by default. It does not drop message roles or reorder messages.
- When reversible pruning happens, the original is stored in `~/.claude-token-optimizer/vault.sqlite3` (permissions are restricted where supported). Treat this local vault as sensitive; retrieve or delete entries deliberately.
- Tool output is not intercepted invisibly. Claude must call the MCP tool before forwarding/using the large content; this avoids promising transparent pre-model interception that a normal MCP tool cannot provide.

## CLI mode

```bash
cat build.log | python3 server.py --cli --mode logs --goal "Find the failing test" --budget 1200
```

## Tests

```bash
python3 -m unittest discover -s tests -v
```

## Inspiration / attribution

This project does not bundle or copy code from these projects. It borrows high-level ideas and provides its own small implementation:

- [Ponytail](https://github.com/DietrichGebert/ponytail) — reduce unnecessary code and favor simple, existing solutions; not a context compressor.
- [Headroom](https://github.com/headroomlabs-ai/headroom) — compress tool outputs, logs, files and conversation history.
- [Microsoft LLMLingua](https://github.com/microsoft/LLMLingua) — prompt compression and budget-aware context selection; this plugin uses a deterministic heuristic instead of its learned models.
- [Atlassian MCP Compressor](https://github.com/atlassian-labs/mcp-compressor) — MCP-oriented compression workflow.
