"""Small, conservative context compression primitives for Claude Code."""
from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from typing import Any, Iterable

VERSION = "1.0.0"
_DIRECTIVE = re.compile(
    r"\b(must|must not|never|do not|don't|only|required|critical|important|cannot|shall)\b|"
    r"\b(wajib|harus|jangan|dilarang|penting|kritis|tidak boleh)\b",
    re.I,
)
_ERROR = re.compile(r"\b(error|exception|traceback|failed|failure|warning|fatal|bug|regression)\b", re.I)
_URL = re.compile(r"https?://\S+|\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)
_NUMBER = re.compile(r"\b(?:\d{4}-\d{2}-\d{2}|v\d+(?:\.\d+)+|(?:id|status|exit(?:\s+code)?|code|port|version|line)\s*[:=#]?\s*\d+|\d+(?:\.\d+)?%)\b", re.I)
_HEADING = re.compile(r"^\s{0,3}#{1,6}\s+|^\s*[-*+]\s+|^\s*\d+[.)]\s+")
_CODE = re.compile(r"^\s{0,3}(```|~~~)")
_WORD = re.compile(r"[\w'-]+", re.UNICODE)


def estimate_tokens(text: str) -> int:
    """Conservative rough estimate; use claude_count_tokens for exact API counts."""
    if not text:
        return 0
    # Character estimate is deliberately labelled approximate and works offline.
    return max(1, math.ceil(len(text.encode("utf-8")) / 3.7))


def _words(text: str) -> set[str]:
    return {w.casefold() for w in _WORD.findall(text) if len(w) > 1}


def _protected(line: str, in_code: bool = False) -> bool:
    s = line.strip()
    if not s:
        return False
    return bool(
        in_code or _DIRECTIVE.search(s) or _ERROR.search(s) or _URL.search(s)
        or _NUMBER.search(s) or _HEADING.match(s) or s.startswith(("```", "~~~"))
    )


def _normalise(text: str) -> str:
    # Only whitespace outside code fences is normalized. Code is kept verbatim.
    out: list[str] = []
    in_code = False
    blank = 0
    for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if _CODE.match(line):
            in_code = not in_code
            out.append(line.rstrip() if not in_code else line)
            blank = 0
            continue
        if in_code:
            out.append(line)
            continue
        line = line.rstrip()
        if not line:
            blank += 1
            if blank <= 1:
                out.append("")
        else:
            blank = 0
            out.append(line)
    return "\n".join(out).strip()


def _dedupe(text: str) -> tuple[str, int]:
    lines = text.splitlines()
    out: list[str] = []
    removed = 0
    in_code = False
    i = 0
    while i < len(lines):
        line = lines[i]
        if _CODE.match(line):
            in_code = not in_code
            out.append(line)
            i += 1
            continue
        if in_code or not line.strip():
            out.append(line)
            i += 1
            continue
        j = i + 1
        while j < len(lines) and lines[j] == line:
            j += 1
        count = j - i
        if count > 1:
            out.append(f"{line} ×{count}")
            removed += count - 1
        else:
            out.append(line)
        i = j
    return "\n".join(out), removed


@dataclass
class Chunk:
    text: str
    index: int
    protected: bool
    score: float
    tokens: int


def _chunk_text(text: str) -> list[str]:
    # Preserve fenced code as a single indivisible chunk.
    lines = text.splitlines()
    chunks: list[str] = []
    buf: list[str] = []
    in_code = False
    for line in lines:
        if _CODE.match(line):
            in_code = not in_code
            buf.append(line)
            if not in_code:
                chunks.append("\n".join(buf))
                buf = []
            continue
        if in_code:
            buf.append(line)
            continue
        if not line.strip():
            if buf:
                chunks.append("\n".join(buf))
                buf = []
            continue
        buf.append(line)
    if buf:
        chunks.append("\n".join(buf))
    return chunks


def _score(chunk: str, idx: int, total: int, goal_words: set[str]) -> tuple[bool, float]:
    lines = chunk.splitlines() or [chunk]
    protected = any(_protected(line, line.lstrip().startswith(("```", "~~~"))) for line in lines)
    words = _words(chunk)
    overlap = len(words & goal_words) / max(1, len(goal_words)) if goal_words else 0.0
    recency = (idx + 1) / max(1, total)
    structural = 0.35 if any(_HEADING.match(x) for x in lines) else 0.0
    density = min(0.2, len(words) / 250)
    return protected, (overlap * 3.0) + (recency * 0.8) + structural + density


def compress_text(
    text: str,
    *,
    goal: str = "",
    budget_tokens: int = 0,
    mode: str = "auto",
    preserve: Iterable[str] = (),
) -> dict[str, Any]:
    """Compress text conservatively. A zero budget means cleanup without truncation."""
    if not isinstance(text, str):
        raise TypeError("text must be a string")
    if mode not in {"auto", "compact", "dedupe", "ranked", "json", "code", "logs"}:
        raise ValueError("unsupported mode")
    if budget_tokens < 0:
        raise ValueError("budget_tokens must be >= 0")

    before = estimate_tokens(text)
    candidate = text
    parsed_json = False
    if mode in {"auto", "json"}:
        try:
            obj = json.loads(text)
            candidate = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
            parsed_json = True
        except (json.JSONDecodeError, TypeError):
            if mode == "json":
                raise ValueError("input is not valid JSON")
    if not parsed_json:
        candidate = _normalise(candidate)
        if mode in {"auto", "dedupe", "logs"}:
            candidate, _ = _dedupe(candidate)

    # JSON minification and code are semantics-sensitive: don't line-prune them.
    can_rank = not parsed_json and mode not in {"json", "code"} and budget_tokens > 0
    omitted: list[str] = []
    if can_rank and estimate_tokens(candidate) > budget_tokens:
        chunks = _chunk_text(candidate)
        goal_words = _words(goal)
        forced_terms = [p.casefold() for p in preserve if p]
        scored: list[Chunk] = []
        for i, part in enumerate(chunks):
            protected, score = _score(part, i, len(chunks), goal_words)
            if any(term in part.casefold() for term in forced_terms):
                protected = True
            scored.append(Chunk(part, i, protected, score, estimate_tokens(part)))
        chosen: set[int] = set()
        used = 0
        # First keep every protected chunk even if that means exceeding the budget.
        for c in scored:
            if c.protected:
                chosen.add(c.index)
                used += c.tokens
        # Then fill remaining budget by relevance + recency, in original order on output.
        for c in sorted(scored, key=lambda x: (x.score, x.index), reverse=True):
            if c.index in chosen:
                continue
            if used + c.tokens <= budget_tokens:
                chosen.add(c.index)
                used += c.tokens
        kept = [c.text for c in scored if c.index in chosen]
        for c in scored:
            if c.index not in chosen:
                omitted.append(c.text)
        if omitted:
            marker = f"[OMITTED {len(omitted)} context block(s). Use retrieve_original with vault_id to recover.]"
            candidate = "\n\n".join(kept + [marker])
        else:
            candidate = "\n\n".join(kept)

    after = estimate_tokens(candidate)
    return {
        "text": candidate,
        "stats": {
            "tokens_before_estimate": before,
            "tokens_after_estimate": after,
            "tokens_saved_estimate": max(0, before - after),
            "reduction_percent_estimate": round(max(0, before - after) * 100 / max(1, before), 1),
            "omitted_blocks": len(omitted),
            "budget_tokens": budget_tokens or None,
            "budget_exceeded_by_protected_content": bool(budget_tokens and after > budget_tokens),
            "token_count_method": "UTF-8 byte heuristic (~3.7 bytes/token); not Claude-exact",
            "json_minified": parsed_json,
        },
        "omitted": omitted,
    }


def compress_messages(
    messages: list[dict[str, Any]], *, goal: str = "", budget_tokens: int = 0,
    keep_last: int = 4, preserve_roles: Iterable[str] = ("system", "developer", "user"),
) -> dict[str, Any]:
    if not isinstance(messages, list) or any(not isinstance(m, dict) for m in messages):
        raise TypeError("messages must be a list of objects")
    if keep_last < 0 or budget_tokens < 0:
        raise ValueError("keep_last and budget_tokens must be >= 0")
    original_total = sum(estimate_tokens(str(m.get("content", ""))) for m in messages)
    fixed_roles = set(preserve_roles)
    fixed_indices = {i for i, m in enumerate(messages) if m.get("role") in fixed_roles}
    fixed_indices.update(range(max(0, len(messages) - keep_last), len(messages)))
    result = [dict(m) for m in messages]
    current_total = original_total
    # Compress largest older tool/assistant messages first; preserve every role and message order.
    candidates = [i for i, m in enumerate(messages) if i not in fixed_indices and m.get("role") in {"tool", "assistant"}]
    candidates.sort(key=lambda i: estimate_tokens(str(messages[i].get("content", ""))), reverse=True)
    omitted_by_message: dict[int, list[str]] = {}
    for i in candidates:
        if not budget_tokens or current_total <= budget_tokens:
            break
        content = result[i].get("content", "")
        if not isinstance(content, str) or not content:
            continue
        other_budget = max(1, budget_tokens - (current_total - estimate_tokens(content)))
        compressed = compress_text(content, goal=goal, budget_tokens=other_budget, mode="auto")
        result[i]["content"] = compressed["text"]
        omitted_by_message[i] = compressed["omitted"]
        current_total -= estimate_tokens(content)
        current_total += estimate_tokens(compressed["text"])
    # If still above target, preserve fixed messages and report the unavoidable overflow.
    after = sum(estimate_tokens(str(m.get("content", ""))) for m in result)
    return {
        "messages": result,
        "omitted": {str(i): parts for i, parts in omitted_by_message.items() if parts},
        "stats": {
            "tokens_before_estimate": original_total,
            "tokens_after_estimate": after,
            "tokens_saved_estimate": max(0, original_total - after),
            "reduction_percent_estimate": round(max(0, original_total - after) * 100 / max(1, original_total), 1),
            "messages_preserved_verbatim": len(fixed_indices),
            "messages_compressed": len(omitted_by_message),
            "budget_tokens": budget_tokens or None,
            "budget_exceeded": bool(budget_tokens and after > budget_tokens),
            "token_count_method": "UTF-8 byte heuristic (~3.7 bytes/token); not Claude-exact",
        },
    }
