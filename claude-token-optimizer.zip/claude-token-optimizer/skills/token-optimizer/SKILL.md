---
name: token-optimizer
description: Reduce unnecessary Claude context and tool-output tokens while preserving task instructions, user intent, important facts, code and errors. Use before carrying large logs, tool outputs or older assistant context forward.
---

# Token Optimizer

Use the `token-optimizer` MCP tools when large text, logs, JSON, tool output, or old conversation messages need to be carried into later work.

1. Prefer `compress_text` for a single large result. Set `goal` to the current task, `mode` to `auto`, and a realistic `budget_tokens` only when there is a genuine context limit.
2. Prefer `compress_messages` for multi-turn history. Its defaults preserve system, developer and user messages verbatim and retain the latest turns. Do not lower that protection unless the user explicitly directs it.
3. Never claim that estimated tokens are exact. Use `claude_count_tokens` only when `ANTHROPIC_API_KEY` is configured and an exact API count is useful.
4. When a call returns `vault_id`, keep it with the result. Use `retrieve_original` before relying on a detail that appears to have been omitted.
5. Do not compress source code, security instructions, requirements, IDs, error messages or exact values just to hit a numeric budget. Protected content may exceed the requested budget; explain that rather than silently deleting it.
6. Use `forget_original` when the saved source is no longer needed, especially if it contained private or sensitive text.

Ponytail-style guidance for code tasks: inspect existing code and dependencies first; prefer standard-library or native features; avoid speculative abstractions and unnecessary dependencies; choose the smallest correct change. Never trade away validation, security, error handling, tests or an explicit user requirement for fewer tokens.
