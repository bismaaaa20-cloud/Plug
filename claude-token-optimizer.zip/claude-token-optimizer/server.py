"""Dependency-free MCP server for Claude Token Optimizer (stdio transport)."""
from __future__ import annotations

import argparse
import json
import os
import sqlite3
import sys
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from optimizer import VERSION, compress_messages, compress_text, estimate_tokens

HOME = Path(os.environ.get("CLAUDE_TOKEN_OPTIMIZER_HOME", Path.home() / ".claude-token-optimizer"))
DB = HOME / "vault.sqlite3"


def _db() -> sqlite3.Connection:
    HOME.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(HOME, 0o700)
    except OSError:
        pass
    con = sqlite3.connect(DB)
    con.execute("CREATE TABLE IF NOT EXISTS vault (id TEXT PRIMARY KEY, kind TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL)")
    con.commit()
    try:
        os.chmod(DB, 0o600)
    except OSError:
        pass
    return con


def _store(kind: str, payload: Any) -> str:
    key = uuid.uuid4().hex[:16]
    with _db() as con:
        con.execute("INSERT INTO vault VALUES (?, ?, ?, ?)", (key, kind, json.dumps(payload, ensure_ascii=False), datetime.now(timezone.utc).isoformat()))
    return key


def _retrieve(key: str) -> Any:
    with _db() as con:
        row = con.execute("SELECT payload FROM vault WHERE id=?", (key,)).fetchone()
    if not row:
        raise KeyError("vault_id not found")
    return json.loads(row[0])


def _delete(key: str) -> bool:
    with _db() as con:
        cur = con.execute("DELETE FROM vault WHERE id=?", (key,))
        return cur.rowcount > 0


def _tool_specs() -> list[dict[str, Any]]:
    obj = {"type": "object", "properties": {}}
    return [
        {"name": "compress_text", "description": "Conservatively compress text, logs, Markdown or JSON. Keeps instructions, errors, numbers, links and code blocks; removed blocks can be restored.", "inputSchema": {"type": "object", "properties": {"text": {"type": "string"}, "goal": {"type": "string"}, "budget_tokens": {"type": "integer", "minimum": 0}, "mode": {"type": "string", "enum": ["auto", "compact", "dedupe", "ranked", "json", "code", "logs"]}, "preserve": {"type": "array", "items": {"type": "string"}}, "reversible": {"type": "boolean", "default": True}}, "required": ["text"]}},
        {"name": "compress_messages", "description": "Reduce older Claude conversation/tool messages while preserving system, developer and user messages verbatim by default, plus the most recent turns.", "inputSchema": {"type": "object", "properties": {"messages": {"type": "array", "items": {"type": "object"}}, "goal": {"type": "string"}, "budget_tokens": {"type": "integer", "minimum": 0}, "keep_last": {"type": "integer", "minimum": 0, "default": 4}, "reversible": {"type": "boolean", "default": True}}, "required": ["messages"]}},
        {"name": "retrieve_original", "description": "Restore the original text/messages saved by a reversible compression operation.", "inputSchema": {"type": "object", "properties": {"vault_id": {"type": "string"}}, "required": ["vault_id"]}},
        {"name": "forget_original", "description": "Permanently delete one locally stored original from the recovery vault.", "inputSchema": {"type": "object", "properties": {"vault_id": {"type": "string"}}, "required": ["vault_id"]}},
        {"name": "claude_count_tokens", "description": "Optionally get Claude's exact input token count via Anthropic's count_tokens API. Requires ANTHROPIC_API_KEY; content is sent only when this tool is called.", "inputSchema": {"type": "object", "properties": {"model": {"type": "string"}, "messages": {"type": "array", "items": {"type": "object"}}, "system": {"type": ["string", "array"]}, "tools": {"type": "array", "items": {"type": "object"}}}, "required": ["model", "messages"]}},
    ]


def _count_claude(args: dict[str, Any]) -> dict[str, Any]:
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        raise ValueError("ANTHROPIC_API_KEY is not set; use the local estimate in stats or configure the key for exact counting")
    body = {"model": args["model"], "messages": args["messages"]}
    for k in ("system", "tools"):
        if k in args:
            body[k] = args[k]
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages/count_tokens",
        data=json.dumps(body).encode("utf-8"),
        headers={"content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read(1000).decode("utf-8", "replace")
        raise RuntimeError(f"Anthropic count_tokens returned HTTP {exc.code}: {detail}") from exc
    return {"input_tokens": data.get("input_tokens"), "method": "Anthropic count_tokens API", "model": args["model"]}


def _call(name: str, args: dict[str, Any]) -> Any:
    if name == "compress_text":
        result = compress_text(args["text"], goal=args.get("goal", ""), budget_tokens=args.get("budget_tokens", 0), mode=args.get("mode", "auto"), preserve=args.get("preserve", []))
        vault_id = _store("text", args["text"]) if args.get("reversible", True) and result["text"] != args["text"] else None
        result.pop("omitted", None)
        result["vault_id"] = vault_id
        return result
    if name == "compress_messages":
        result = compress_messages(args["messages"], goal=args.get("goal", ""), budget_tokens=args.get("budget_tokens", 0), keep_last=args.get("keep_last", 4))
        omitted_count = sum(len(parts) for parts in result.get("omitted", {}).values())
        vault_id = _store("messages", args["messages"]) if args.get("reversible", True) and result["messages"] != args["messages"] else None
        result.pop("omitted", None)  # Never return pruned source blocks in the compressed response.
        result["stats"]["omitted_blocks"] = omitted_count
        result["vault_id"] = vault_id
        return result
    if name == "retrieve_original":
        return {"vault_id": args["vault_id"], "original": _retrieve(args["vault_id"])}
    if name == "forget_original":
        return {"vault_id": args["vault_id"], "deleted": _delete(args["vault_id"])}
    if name == "claude_count_tokens":
        return _count_claude(args)
    raise ValueError(f"unknown tool: {name}")


def _response(message_id: Any, result: Any = None, error: dict[str, Any] | None = None) -> dict[str, Any]:
    if error is not None:
        return {"jsonrpc": "2.0", "id": message_id, "error": error}
    return {"jsonrpc": "2.0", "id": message_id, "result": result}


def _handle(message: dict[str, Any]) -> dict[str, Any] | None:
    method = message.get("method")
    mid = message.get("id")
    params = message.get("params") or {}
    if method == "notifications/initialized" or method == "notifications/cancelled":
        return None
    if method == "initialize":
        version = params.get("protocolVersion", "2024-11-05")
        if version not in {"2024-11-05", "2025-03-26", "2025-06-18"}:
            version = "2025-06-18"
        return _response(mid, {"protocolVersion": version, "capabilities": {"tools": {"listChanged": False}}, "serverInfo": {"name": "claude-token-optimizer", "version": VERSION}, "instructions": "Use compression conservatively. Preserve system/developer/user intent. Use retrieve_original when a vault_id is returned."})
    if method == "ping":
        return _response(mid, {})
    if method == "tools/list":
        return _response(mid, {"tools": _tool_specs()})
    if method == "tools/call":
        try:
            args = params.get("arguments") or {}
            result = _call(params.get("name", ""), args)
            return _response(mid, {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}], "isError": False})
        except Exception as exc:
            return _response(mid, {"content": [{"type": "text", "text": f"{type(exc).__name__}: {exc}"}], "isError": True})
    if mid is not None:
        return _response(mid, error={"code": -32601, "message": f"Method not found: {method}"})
    return None


def serve() -> int:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
            reply = _handle(message)
            if reply is not None:
                sys.stdout.write(json.dumps(reply, ensure_ascii=False, separators=(",", ":")) + "\n")
                sys.stdout.flush()
        except Exception as exc:
            sys.stdout.write(json.dumps(_response(None, error={"code": -32700, "message": str(exc)}), separators=(",", ":")) + "\n")
            sys.stdout.flush()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", action="version", version=VERSION)
    parser.add_argument("--cli", action="store_true", help="compress stdin text and print the optimized result")
    parser.add_argument("--goal", default="")
    parser.add_argument("--budget", type=int, default=0, help="rough token budget; 0 only compacts/deduplicates")
    parser.add_argument("--mode", default="auto", choices=["auto", "compact", "dedupe", "ranked", "json", "code", "logs"])
    args = parser.parse_args()
    if args.cli:
        source = sys.stdin.read()
        print(json.dumps(compress_text(source, goal=args.goal, budget_tokens=args.budget, mode=args.mode), ensure_ascii=False, indent=2))
        return 0
    return serve()


if __name__ == "__main__":
    raise SystemExit(main())
