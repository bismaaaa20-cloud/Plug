import json
import unittest

from optimizer import compress_messages, compress_text, estimate_tokens


class CompressionTests(unittest.TestCase):
    def test_empty_and_estimate(self):
        self.assertEqual(estimate_tokens(""), 0)
        self.assertGreater(estimate_tokens("hello world"), 0)

    def test_json_minifies_without_dropping_fields(self):
        source = '{\n  "a": 1,\n  "b": [2, 3]\n}'
        result = compress_text(source, mode="auto")
        self.assertEqual(json.loads(result["text"]), json.loads(source))
        self.assertTrue(result["stats"]["json_minified"])

    def test_repeated_lines_are_marked(self):
        result = compress_text("ok\nok\nok\nnext", mode="dedupe")
        self.assertIn("×3", result["text"])
        self.assertEqual(result["stats"]["tokens_after_estimate"] <= result["stats"]["tokens_before_estimate"], True)

    def test_directives_and_code_are_protected(self):
        source = """intro words repeated many times\n\nNEVER remove this rule.\n\n```python\nraise RuntimeError('keep')\n```\n\nold unrelated detail"""
        result = compress_text(source, goal="intro", budget_tokens=10, mode="ranked")
        self.assertIn("NEVER remove this rule", result["text"])
        self.assertIn("raise RuntimeError", result["text"])
        self.assertTrue(result["stats"]["budget_exceeded_by_protected_content"] or result["stats"]["omitted_blocks"] > 0)

    def test_preserve_custom_terms(self):
        result = compress_text("alpha block\n\nbeta mandatory-ref-123\n\ngamma block", budget_tokens=1, preserve=["mandatory-ref-123"])
        self.assertIn("mandatory-ref-123", result["text"])

    def test_messages_keep_user_system_and_recent(self):
        messages = [
            {"role": "system", "content": "System rule"},
            {"role": "assistant", "content": "A " * 500 + "old output"},
            {"role": "user", "content": "Do not change requirement"},
            {"role": "assistant", "content": "latest answer"},
        ]
        result = compress_messages(messages, budget_tokens=5, keep_last=1)
        self.assertEqual(result["messages"][0], messages[0])
        self.assertEqual(result["messages"][2], messages[2])
        self.assertEqual(result["messages"][3], messages[3])


if __name__ == "__main__":
    unittest.main()
