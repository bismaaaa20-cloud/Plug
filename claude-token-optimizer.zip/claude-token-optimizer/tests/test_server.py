import tempfile
import unittest
from pathlib import Path

import server


class MCPServerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_home, self.old_db = server.HOME, server.DB
        server.HOME = Path(self.tmp.name)
        server.DB = server.HOME / "vault.sqlite3"

    def tearDown(self):
        server.HOME, server.DB = self.old_home, self.old_db
        self.tmp.cleanup()

    def test_initialize_handshake(self):
        reply = server._handle({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-06-18"}})
        self.assertEqual(reply["result"]["protocolVersion"], "2025-06-18")
        self.assertIn("tools", reply["result"]["capabilities"])

    def test_tool_list_contains_compress_and_recovery(self):
        reply = server._handle({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
        names = {tool["name"] for tool in reply["result"]["tools"]}
        self.assertTrue({"compress_text", "compress_messages", "retrieve_original", "forget_original", "claude_count_tokens"} <= names)

    def test_reversible_compression_can_restore_exact_original(self):
        original = "First paragraph with lots of unrelated material.\n\nSecond paragraph with other details."
        compressed = server._call("compress_text", {"text": original, "budget_tokens": 3, "mode": "ranked", "reversible": True})
        self.assertTrue(compressed["vault_id"])
        restored = server._call("retrieve_original", {"vault_id": compressed["vault_id"]})
        self.assertEqual(restored["original"], original)
        removed = server._call("forget_original", {"vault_id": compressed["vault_id"]})
        self.assertTrue(removed["deleted"])

    def test_compressed_response_does_not_echo_omitted_source(self):
        original = "old confidential phrase alpha\n\nold confidential phrase beta"
        compressed = server._call("compress_text", {"text": original, "budget_tokens": 1, "mode": "ranked", "reversible": True})
        serialized = str(compressed)
        self.assertNotIn("old confidential phrase", serialized)


if __name__ == "__main__":
    unittest.main()
