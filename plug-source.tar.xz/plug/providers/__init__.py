"""Provider contracts and registry."""
