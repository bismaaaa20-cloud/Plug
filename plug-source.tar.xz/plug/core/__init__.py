"""Planning and execution primitives."""
